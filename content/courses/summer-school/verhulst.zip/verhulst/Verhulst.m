% To solve numerically Verhulst equation, we will use Symbolic matlab
% toolbox. We thus have to define symbols 

syms k X N ;

% and define the equation

f = k * X * (1 - X/N)

% N = k/b

syms b

f1 = k * X * (1 - X*b/k) 

% let's solve it

fs = solve (f1, X) 

% Build the Jacobian 

J = jacobian (f1, X) 

% Subsituute X with the steady states

e1 = simplify(subs(J, X, fs(1))) %subsitute with the first steady state
e2 = simplify(subs(J, X, fs(2))) %subsitute with the second steady state

% find eigenvalue

w1 = simplify(eig(e1))
w1 = simplify(eig(e2))

% Notice that the first solution X_s = 0 is stable for k < 0 and unstable
% for k > 0 (as the sign of the eigenvalue depends on the sign of k). The
% second solution X_s = k/N is stable for k > 0 and unstable for k < 0
% (as the sign of the eigenvalue depends on the negative sign of k) 

% Plot the bifurcaton diagram with b = 1

fs2 = subs(fs, {b}, 1)

figure (1)
ezplot(fs2(1), [-1:1])
hold on
ezplot(fs2(2), [-1:1])
ylabel 'x_s'
xlabel 'k'
box off

% Another possibility is to plot your solutions without ezplot (if you
% have an analytic solution as it is our case now). Clear k and b  because they
% will not be symbols for matlab anymore.

clear k b
k =[-1:0.01:1] ; 
b= 1 ;
for i = 1:200
    kk (i) = k (i) ;
    if kk(i) < 0
        x1s (i) = 0 ;  % x1s is x_1 stable for k < 0
        x2u (i) = kk(i)/b ; % x2u is x_2 unstable for k < 0
        
        % putting x1u and x2s NaN 
        
        x1u (i) = NaN ;
        x2s (i) = NaN ;
    else % if k >0
        x1u (i) = 0 ;  % now x_1 =0 is unstable
        x2s (i) = kk(i)/b ; % and x_2 is stable
        
        x1s (i) = NaN ;
        x2u (i) = NaN ;
    end
end

% Now plot the bifurcation diagram properly

figure,
plot (kk, x1s, '-') % plain line is the convention for stable solutions
hold on
plot (kk, x2s, '-')
plot (kk, x1u, '--') % dashed line for unstable solutions
plot (kk, x2u, '--')
ylabel 'x_s'
xlabel 'k'
box off

% Numerical integration and phase space portraits
% Download the file odeverhulst.m

clear

% Define time, initial conditions  and parameters

time=[0:50];
k = 0.3
N = 1
init = 0.01
[T X] = ode45('odeverhulst', time, [init], [], k, N);

figure,
plot(T, X)
xlabel 'Time'
ylabel 'X'
box off
axis([-1 51 -0.01 1.01])

% Let's plot many initial conditions to see if we haven forgot anything 

% create a vector of 100 random numbers
 figure,
init= rand(1, 100) ;
for i = 1:100
    [T1 X1] = ode45('odeverhulst', time, [init(i)], [], k, N) ;

    plot(T1, X1)
    hold on
end
xlabel 'Time'
ylabel 'X'
box off
axis([-1 51 -0.01 1.01])

% Try to go to the other stable solution when k < 0




