%Save this as verhulst.m
function Fun = odefile(t, x, flag, k, N)
Fun = [
k*x(1)*(1-x(1)/N)
];